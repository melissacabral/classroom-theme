<?php
//this file runs before the theme header.php. You can use it to control the theme, admin panel and login forms

//turn on "featured images" 
add_theme_support( 'post-thumbnails' ); 

//custom image sizes (name, width, height, crop (bool))
add_image_size( 'awesome-short-banner', 960, 113, true );
add_image_size( 'awesome-banner', 960, 330, true );
add_image_size( 'awesome-gallery', 190, 152, true );
add_image_size( 'awesome-news-widget-thumb', 240, 152, true );



//no close php