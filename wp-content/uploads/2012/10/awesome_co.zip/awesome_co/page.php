<?php get_header(); ?>

<?php //THE LOOP.
if( have_posts() ): 
    while( have_posts() ):
    the_post(); ?>
    
<?php //featured image display. check first to make sure one exists
    if( has_post_thumbnail() ): ?>
        <div class="banner">
        <?php the_post_thumbnail( 'awesome-short-banner' ); ?>
        </div>
<?php endif;?>    

 <div id="content">	
        
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?>>
        <h2 class="entry-title">  
            <?php the_title(); ?> 
        </h2>                

        <div class="entry-content">
            <?php the_content(); ?>
        </div>
   
    </article><!-- end post -->
    
 </div><!-- end content -->
 
  <?php 
  endwhile;
  else: ?>
  <h2>Sorry, no posts found</h2>
  <?php endif; //END OF LOOP. ?>
    

    
<?php get_sidebar(); ?> 
<?php get_footer(); ?>  