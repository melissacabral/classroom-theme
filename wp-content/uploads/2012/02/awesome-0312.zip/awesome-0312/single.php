<?php get_header(); ?>
<div id="content">  

<?php
	//basic loop. begin by checking if there are posts to show
	if( have_posts() ):
		//loop through them
		while( have_posts() ): the_post();
?>
 
	<div id="post-<?php the_ID(); ?>" <?php post_class(); //puts dynamic class on each post ?>>             
		<h2 class="entry-title"><?php the_title(); ?></h2>
	
		<div class="entry-content">
			<?php the_content();?>
	
		<?php //TODO: improve: make this div go away if the post is not paginated ?>
			<div class="pagination">
				<?php //use pagenavi (cool plugin) if it exists
				if( function_exists('wp_pagenavi') ):
					wp_pagenavi( array( 'type' => 'multipart' ) );
				else:
					//no pagenavi, use the default WP way
					wp_link_pages(); 
				endif; //pagenavi exists?>
			</div> <!-- end pagination -->
			
		</div><!-- end entry-content -->
	
	<?php comments_template(); ?>
	
	</div><!-- end post -->
	
<?php endwhile;  //end looping posts
else: //no posts found. alternate content: ?>
	<div class="post">Sorry, no posts found. Try the search bar.</div>
<?php endif; //end of alternate content ?>
	
</div><!-- end content --> 
    
<?php get_sidebar( 'page' ); //include the file sidebar-page.php ?>    
<?php get_footer(); ?>