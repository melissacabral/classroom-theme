<?php 
/*
	Template Name: Automatic Sitemap
*/
?>
<?php get_header(); ?>
<div id="content">  

<?php
	//basic loop. begin by checking if there are posts to show
	if( have_posts() ):
		//loop through them
		while( have_posts() ): the_post();
?>
 
 <div id="post-<?php the_ID(); ?>" <?php post_class(); //puts dynamic class on each post ?>>             
		<h2 class="entry-title"><?php the_title(); ?></h2>
	
		<div class="entry-content">
			<?php the_content();?>
			
			<div class="onethird">
				<h3>Pages</h3>
				<ul>
					<?php wp_list_pages( array(
						'title_li' => '',
						
					) ); ?>
				</ul>
				
				<h3>Archives</h3>
				<ul>
					<?php wp_get_archives(); ?>
				</ul>	
			</div><!-- end onethird -->
			
			<div class="onethird">
				<h3>Blog Posts</h3>
				<ul>
					<?php wp_get_archives( array(
						'type' => 'postbypost' //posts by date. use 'alpha' for posts by name
					) ); ?>
				</ul>
			</div><!-- end onethird -->
			
			<div class="onethird">
				<h3>Feeds</h3>
				<ul>
					<li><a href="<?php bloginfo('rss2_url'); ?>">RSS feed of posts</a></li>
					<li><a href="<?php bloginfo('comments_rss2_url'); ?>">RSS feed of comments</a></li>
				</ul>
				
				<h3>Categories</h3>
				<ul>
					<?php wp_list_categories( array(
						'title_li' => '',
						'hierarchical' => 0
					) ); ?>
				</ul>
			</div><!-- end onethird -->
			
		</div><!-- end entry-content -->
	</div><!-- end post -->
	
	
<?php endwhile;  //end looping posts
else: //no posts found. alternate content: ?>
	<div class="post">Sorry, no posts found. Try the search bar.</div>
<?php endif; //end of alternate content ?>
	
</div><!-- end content --> 
      
<?php get_footer(); ?>