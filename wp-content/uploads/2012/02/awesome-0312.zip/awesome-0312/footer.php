</div>
<!-- end wrapper. opened in header -->

<div id="footer" class="clearfix"> 
	<?php //if there are widgets in the footer area, show them, otherwise, show the copyright info
	if( !dynamic_sidebar( 'Footer Area' ) ):
	 ?>    
		<div class="widget">        
			&copy; <?php echo date('Y'); ?> - <?php bloginfo('name'); ?>
		</div>
	<?php endif; ?>	
</div><!-- end footer -->
<?php wp_footer(); //ALWAYS include this before </body> so plugin JS will work ?>
</body>
</html>