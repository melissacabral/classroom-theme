<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>;charset=<?php bloginfo('charset') ?>" />
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/reset.css" type="text/css" media="screen" />


<title>
<?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>
</title>

<?php wp_head();  //ALWAYS put this in the <head> so plugin JS and CSS will work ?>
<!-- put stylesheet call AFTER wp_head so it will be more specific than plugin styles -->
<link rel="stylesheet" type="text/css" media="all" href="<?php 
bloginfo('stylesheet_url'); ?>" /> 

</head>
<body <?php body_class(); //puts dynamic classes on every page ?>>
<div id="wrapper" class="clearfix">
<!-- wrapper closes in footer -->
<div id="header">
	<h1 class="site-name"><a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>" rel="home">
		<?php bloginfo('name'); ?>
		</a></h1>
	<h2 class="site-description">
		<?php bloginfo('description'); ?>
	</h2>
	
	<?php get_search_form(); //show the default searchform unless over-ridden by searchform.php ?>
	
	
	<ul class="utilities">
		<?php 
		//show the utilities menu area if it exists
		if( has_nav_menu('utilities') ):
			wp_nav_menu( array(
				'theme_location' => 'utilities',
				'container' => '', //no wrapping div
				'items_wrap' => '%3$s', //remove the ul around it. %3$s represents all the list items with links. see the codex for the default value. 
				'fallback_cb' => '' //no fallback callback function
			) );
		else:
		
			//show ONLY pages 2 and 146
			wp_list_pages(array(
				'title_li' => '',
				'include' => '2,146' 
			));  
		
		endif;
		?>
	</ul>
	
	
	
	<ul class="nav">
		<?php 
		//show the utilities menu area if it exists
		if( has_nav_menu('main_menu') ):
			wp_nav_menu( array(
				'theme_location' => 'main_menu',
				'container' => '', //no wrapping div
				'items_wrap' => '%3$s', //remove the ul around it. %3$s represents all the list items with links. see the codex for the default value. 
				'fallback_cb' => '' //no fallback callback function
			) );
		else:
		
			//show all top level pages EXCEPT 2 and 146		
			wp_list_pages(array(
				'depth' => 1,
				'title_li' => '',
				'exclude' => '2,146'
			));  
		
		endif;
		?>
	</ul>
</div>
    <!-- end header -->




