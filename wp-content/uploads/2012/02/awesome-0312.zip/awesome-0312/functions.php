<?php
//adds a menu item under appearance > background to change the body background
add_custom_background();

//adds featured images to posts and pages
add_theme_support('post-thumbnails');

//add more image sizes (name, width, height, crop)
add_image_size( 'awesome-frontpage', 960, 330, true );
add_image_size( 'awesome-banner', 960, 152, true );


//add RSS links to the head
add_theme_support('automatic-feed-links');

//activate editor-style.css so the admin panel posts look like the front end display of the site
add_editor_style();


// enable threaded comment reply 
function enable_threaded_comments(){
    if ( (!is_admin())  && is_singular() AND comments_open() AND (get_option('thread_comments'))){
            wp_enqueue_script('comment-reply');
        }  
   
}
add_action('wp_print_scripts', 'enable_threaded_comments');

//change the length of excerpts
function rad_excerpt_length( $length ){
	return 60;
}
//call it at the right time
add_filter( 'excerpt_length', 'rad_excerpt_length' );


//change the [...] after excerpts
function rad_excerpt_more(){
	return '<a class="readmore" href="'. get_permalink() .'">Read More</a>';
}
add_filter( 'excerpt_more', 'rad_excerpt_more' );

//create 2 menu areas on init (when WP starts up). the code to display them is in header.php 
function rad_menu_setup(){
	register_nav_menus( array(
	//use UNDERSCORES on the left
		'main_menu' => 'Main Menu Area',
		'utilities' => 'Utility Area'
	) );
}
add_action( 'init', 'rad_menu_setup' );

//add 4 widget areas (dynamic sidebars)
if( function_exists('register_sidebar') ){
	register_sidebar( array(
		'name' => 'Home Page Sidebar',
		'description' => 'An area at the bottom of the front page of the site',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
	//repeat register_sidebar for more sidebars
	register_sidebar( array(
		'name' => 'Main Sidebar',
		'description' => 'This appears next to blog and archive pages',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
	register_sidebar( array(
		'name' => 'Page Sidebar',
		'description' => 'This appears next to pages',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
	register_sidebar( array(
		'name' => 'Footer Area',
		'description' => 'Appears at the bottom of all views',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
}






//no close php tag! this prevents accidental white space errors