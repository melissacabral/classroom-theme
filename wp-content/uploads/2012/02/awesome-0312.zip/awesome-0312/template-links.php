<?php 
/*
	Template Name: Links
*/
?>
<?php get_header(); ?>
<div id="content">  

	<div <?php post_class(); ?>>
		<h2 class="entry-title"> <?php the_title(); ?> </h2>
		<div class="entry-content">
			
				<?php wp_list_bookmarks( array(
					'show_description' => 1,
					'category_before' =>'',
					'category_after' => '',
					'between' => ' - ',
					'title_li' => ''
				) ); ?>
			
		</div>
	</div>
	
</div><!-- end content --> 
    
<?php get_sidebar( 'page' ); //include the file sidebar-page.php ?>    
<?php get_footer(); ?>