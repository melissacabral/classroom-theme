<?php get_header(); ?>
<div id="content">         

	
	
<?php
	//basic loop. begin by checking if there are posts to show
	if( have_posts() ):
		//loop through them
		while( have_posts() ): the_post();
?>
 
 <div id="post-<?php the_ID(); ?>" <?php post_class(); //puts dynamic class on each post ?>>             
		<h2 class="entry-title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<div class="postmeta">
			<span class="author"> Posted by: <?php the_author(); ?> </span>
			<span class="date"> <?php the_date(); ?> </span>
			<span class="num-comments"> <?php comments_number(); ?> </span>
			<span class="categories"> <?php the_category(); ?> </span>
			<span class="tags"><?php the_tags(); ?></span>
		</div><!-- end postmeta -->
		
	<?php
	//if this post has a thumbnail, show it
	if( has_post_thumbnail() ):
	 ?>
		<div class="thumb">
		<?php the_post_thumbnail('thumbnail'); ?>
		</div>
	<?php endif; //has post thumb ?>

		<div class="entry-content">
			<?php 
			//if viewing a single post or page, show the content, otherwise, the excerpt
			if( is_single() || is_page() ):
				the_content();			
			else:
				the_excerpt(); //short version of the_content()
			endif; ?>
		</div><!-- end entry-content -->
	</div><!-- end post -->
	
	
<?php endwhile;  //end looping posts
else: //no posts found. alternate content: ?>
	<div class="post">Sorry, no posts found. Try the search bar.</div>
<?php endif; //end of alternate content ?>
	
	
	<div id="nav-below" class="pagination">
		<?php //run the pagenavi plugin if it exists
		if( function_exists('wp_pagenavi') ):
			wp_pagenavi();	
		else:
		 ?>
			<?php next_posts_link('&larr; Older Posts'); //older = next ?>
			<?php previous_posts_link('Newer Posts &rarr;'); //newer = prev ?>
		
		<?php endif; //pagenavi exists ?>
	</div>	<!-- end #nav-below --> 
</div><!-- end content --> 
    
<?php get_sidebar(); ?>
    
<?php get_footer(); ?>
