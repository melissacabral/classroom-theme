<div id="sidebar">

<?php dynamic_sidebar( 'Home Page Sidebar' ); ?>

</div>