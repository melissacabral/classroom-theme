<div id="sidebar">  
	<?php //if there are widgets in the sidebar, show them, otherwise, show fallback stuff
	if( !dynamic_sidebar( 'Main Sidebar' ) ):
	 ?> 
	 MELISSA'S CODE      
	<div id="categories" class="widget">             
		<h3 class="widget-title"> Categories </h3>
		<ul>
			<?php 
			//only show 10 cats on the front page, otherwise, show all cats
			if( is_front_page() ):
				$number = 10;
			else:
				$number = '';
			endif;
			//get most used categories for the whole blog
			wp_list_categories( array(
				'title_li' => '',
				'show_count' => 1,
				'orderby' => 'count',
				'order' => 'DESC',
				'number' => $number
			) ); ?>
		</ul>
	</div>
	
	<div id="archives" class="widget">             
		<h3 class="widget-title"> Archives </h3>
		<ul>
			<?php wp_get_archives( array(
				'type' => 'yearly',
				'show_post_count' => 1
			) ); ?>
		</ul>
	</div>
	
	<div id="tags" class="widget">             
		<h3 class="widget-title"> Tags </h3>
		<?php wp_tag_cloud( array(
			'smallest' => 9, 
    		'largest' => 16,) ); ?>
	</div>
	
	<div id="meta" class="widget">             
		<h3 class="widget-title"> Admin Stuff </h3>
		<ul>
			<?php wp_register(); // show the register link if registration is open ?>
			
			<li><?php 
			//wp_loginout();
			
			//this next logic replaces wp_loginout with a login form:
			   if( !is_user_logged_in() ): // if not logged in
					 wp_login_form(); //show the login form
			   else: //user is logged in, show logout
					$redirect = home_url();
					echo '<a href="'.wp_logout_url( $redirect ).'">Log Out</a>';
			   endif;?>
			</li>
		</ul>
	</div>
	<?php endif; //widget area ?>
</div> <!-- end sidebar --> 




