<div id="sidebar">
	<div class="widget">
		<?php
		//if we are viewing a child page
		if($post->post_parent)
			//get the siblings
			$children = wp_list_pages("title_li=&child_of=".$post->post_parent."&echo=0");
		else //we are viewing a top level page
			//get children of this post
			$children = wp_list_pages("title_li=&child_of=".$post->ID."&echo=0");
		
		if ($children) { ?>
		<h3>Related Pages</h3>
		<ul>
		<?php echo $children; ?>
		</ul>
		<?php } ?>

	</div>
	
	<?php //if there are widgets in the Page sidebar, show them
	if( !dynamic_sidebar( 'Page Sidebar' ) ):
		//optional stuff here if you want... I don't.
	endif;
	 ?>
	 
</div>


