</div><!-- end wrapper. Opened in header.php -->

<div id="footer" class="clearfix">
    <div class="widget-container">        
        &copy; 2012 Awesome Co.        
    </div>
</div><!-- end footer -->
<?php wp_footer(); //IMPORTANT. must go before </body> for javascript plugins ?>
</body>
</html>