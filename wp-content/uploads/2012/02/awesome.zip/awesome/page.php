<?php get_header(); ?>
    
    <div id="content">       
       
       <?php //main loop
	   if( have_posts() ):
	    ?>
		
		<?php while( have_posts() ): the_post(); ?>
        
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h2 class="entry-title">  <?php the_title(); ?> </h2>                 
            
            <div class="entry-content">
				
                	<?php the_content(); ?>
				
            </div>
        </div><!-- end post --> 
		
		<?php endwhile; //end of main post loop ?>
		
		
		<?php 
		else: //no posts to show
		
			echo 'Sorry, no posts match your criteria.';
		
		endif; //end if there are posts to show in the loop ?>
        
    </div><!-- end content -->
    
  <?php get_sidebar('page'); //include sidebar-page.php ?>
  <?php get_footer(); ?>
    
