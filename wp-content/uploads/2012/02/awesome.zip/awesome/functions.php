<?php
//turn on featured images for each post
add_theme_support( 'post-thumbnails' ); 