  <div id="sidebar">
        <div id="categories" class="widget">
            <h3 class="widget-title"> Categories </h3>
            <ul>
                <?php wp_list_categories( array(
						'number' => 10,
						'title_li' => '',
						'show_count' => 1,
						'orderby' => 'count',
						'order' => 'DESC'
				) ); ?>                
            </ul>
        </div>
        <div id="archives" class="widget">
            <h3 class="widget-title"> Archives </h3>
            <ul>
                <?php wp_get_archives( array(
						'type' => 'yearly',
						'show_post_count' => 1
				) ); ?>
            </ul>
        </div>
        <div id="tags" class="widget">
            <h3 class="widget-title"> Tags </h3>
            
			<?php wp_tag_cloud( array(
					'smallest' => 10,
					'largest' => 16,
					'number' => 30
			) ); ?>
			
        </div>
        <div id="meta" class="widget">
            <h3 class="widget-title"> Meta </h3>
            <ul>
                <?php wp_register(); ?>
                <li> <?php wp_loginout(); ?> </li>
            </ul>
        </div>
    </div><!-- end sidebar --> 