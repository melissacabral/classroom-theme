<?php get_header(); ?>
    
    <div id="content"> 
	
	<?php
	//turn on breadcrumbs if the function exists
	if( function_exists( 'dimox_breadcrumbs' ) ){
		dimox_breadcrumbs();
	}
	 ?>
	      
       
       <?php //main loop
	   if( have_posts() ):
	    ?>
		
		<?php while( have_posts() ): the_post(); ?>
        
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
            <div class="postmeta"> 
                <span class="author"> Posted by: <?php the_author(); ?> </span> 
                <span class="date"> <?php the_date(); ?> </span> 
                <span class="num-comments"> 
				<?php comments_number('No comments yet!', 'One Comment', '% Comments'); ?> </span> 
                
                <span class="tags"><?php the_tags(); ?></span> 
            </div><!-- end postmeta --> 
			
			<?php 
			if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it. ?>
  				<div class="thumb">
				<?php the_post_thumbnail('awesome-thumbnail'); ?>
				<h3 class="category">
					<?php 
					//get all the categories assigned to this post (array)
					$category = get_the_category(); 
					//if it has at least one category
					if($category[0]){
						//show one category
						echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
					}
					?>
				</h3>
				</div> <!-- end thumb -->
			<?php } ?>           
            
            <div class="entry-content">
				<?php if( is_single() || is_page() ){ ?>
                	<?php the_content(); ?>
				<?php }else{ ?>
					<?php the_excerpt(); ?>
				<?php } ?>
            </div>
        </div><!-- end post --> 
		
		<?php endwhile; //end of main post loop ?>
		
		       
        
        <div id="nav-below" class="pagination"> 
            <?php 
			if( function_exists( 'wp_pagenavi' ) ){
				wp_pagenavi();
			}else{
				next_posts_link('&larr; Older Posts');
				previous_posts_link('Newer Posts &rarr;');
			}
			?>			
        </div><!-- end #nav-below --> 
		
		<?php 
		else: //no posts to show
		
			echo 'Sorry, no posts match your criteria.';
		
		endif; //end if there are posts to show in the loop ?>
        
    </div><!-- end content -->
    
  <?php get_sidebar(); ?>
  <?php get_footer(); ?>
    
