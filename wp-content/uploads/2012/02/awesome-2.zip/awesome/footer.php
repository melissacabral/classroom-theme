</div><!-- end wrapper. Opened in header.php -->

<div id="footer" class="clearfix">
    <?php 
	//check to see if home widget area does not exist or have any widgets
	if(!dynamic_sidebar('Footer')){
		//alternate content here ?>
	
	<div class="widget-container">        
        &copy; 2012 Awesome Co.        
    </div>
	
	<?php } 	?>
</div><!-- end footer -->
<?php wp_footer(); //IMPORTANT. must go before </body> for javascript plugins ?>
</body>
</html>