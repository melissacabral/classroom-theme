<?php 
/*
Template Name: Sitemap
*/
?>
<?php get_header(); ?>
    
    <div id="content">  
	
	<?php
	//turn on breadcrumbs if the function exists
	if( function_exists( 'dimox_breadcrumbs' ) ){
		dimox_breadcrumbs();
	}
	 ?>     
       
       <div <?php post_class(); ?>>
	   		<h2><?php the_title(); ?></h2>
			
			<div class="onethird">
				<h3>Categories</h3>
				<ul>
				 <?php wp_list_categories( array(
				 	'title_li' => '',
					'hierarchical' => 0,
					'show_count' => 1,
					'feed' => 'rss',
				 ) ); ?>
				</ul>
			</div>
			
			<div class="onethird">
				<h3>Pages</h3>
				<ul>
					<?php wp_list_pages(array(
				 	'title_li' => ''
				 ) ); ?>
				</ul>			
			</div>
			
			<div class="onethird">
				<h3>Blog Posts</h3>
				<ul>
					<?php $post_archive = new WP_Query('posts_per_page=-1'); 
					//run a loop
					while($post_archive->have_posts()):  
						$post_archive->the_post();
					?>
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><?php comments_number('',' (1 comment)',' (% comments)'); ?></li>
					<?php endwhile; ?>
				</ul>
			
			</div>			
			
	   
	   </div><!-- end post -->
        
    </div><!-- end content -->
    
<?php get_footer(); ?>