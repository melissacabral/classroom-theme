<?php get_header(); ?>
    
    <div id="content"> 
	
	<?php
	//turn on breadcrumbs if the function exists
	if( function_exists( 'dimox_breadcrumbs' ) ){
		dimox_breadcrumbs();
	}
	 ?>
	      
       
       <?php //main loop
	   if( have_posts() ):
	    ?>
		
		<?php while( have_posts() ): the_post(); ?>
        
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
            <div class="postmeta"> 
                <span class="author"> Posted by: <?php the_author(); ?> </span> 
                <span class="date"> <?php the_date(); ?> </span> 
                <span class="num-comments"> 
				<?php comments_number('No comments yet!', 'One Comment', '% Comments'); ?> </span> 
                
                <span class="tags"><?php the_tags(); ?></span> 
            </div><!-- end postmeta --> 
			
			          
            
            <div class="entry-content">
				
                	<?php the_content(); ?>
				
            </div>
         
		 <div id="nav-below" class="pagination"> 
            <?php 
			previous_post_link( '%link', 'Earlier: %title' );
			next_post_link( '%link', 'Later: %title' );
			?>			
        </div><!-- end #nav-below --> 
		
		
		
		<?php //show the comments
			comments_template(); 
		?>
		
		</div><!-- end post --> 
		
		<?php endwhile; //end of main post loop ?>
		
		       
        
       
		
		<?php 
		else: //no posts to show
		
			echo 'Sorry, no posts match your criteria.';
		
		endif; //end if there are posts to show in the loop ?>
        
    </div><!-- end content -->
    
  <?php get_sidebar(); ?>
  <?php get_footer(); ?>
    
