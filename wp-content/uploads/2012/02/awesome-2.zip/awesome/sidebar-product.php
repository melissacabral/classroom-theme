<div id="sidebar">
	<h2>Filter Products By:</h2>
	
	<div class="widget">
		<h3>Brands:</h3>
		
		<ul>
			<?php wp_list_categories( array(
				'taxonomy' => 'brand',
				'title_li' => ''
			) ); ?>
		</ul>
	</div>
	
	
	<div class="widget">
		<h3>Features:</h3>
		
		<?php wp_tag_cloud( array(
			'taxonomy' => 'feature',
				
		) ); ?>
		
	</div>
	
</div>