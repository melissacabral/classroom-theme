<?php 
/*
	File to display single products (custom post type created by plugin)
*/
?>
<?php get_header(); ?>
    
    <div id="content"> 
	
	<?php
	//turn on breadcrumbs if the function exists
	if( function_exists( 'dimox_breadcrumbs' ) ){
		dimox_breadcrumbs();
	}
	 ?>
	      
       
       <?php //main loop
	   if( have_posts() ):
	    ?>
		
		<?php while( have_posts() ): the_post(); ?>
        
        <div id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?>>
			<?php 
			//check for thumbnail
			if( has_post_thumbnail() ){
				the_post_thumbnail('medium', array('class' => 'alignright'));
			} ?>           
           
		   
		   <div class="product-info">
		   
		   		<h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>				
				
	<?php 
	//(post id, taxonomy, before list, separator, after list)
	the_terms( $post->ID, 'brand', '<p><h3>Brand:</h3> ', ' , ', '</p>' ); 
	
	the_terms( $post->ID, 'feature', '<p><h3>Features:</h3> ', ' , ', '</p>' ); 
	?>
				
				<?php the_meta(); ?>
							
				
				<?php the_content(); ?>				
			
		   </div> <!-- end .product-info -->        
            
          
         
		 <div id="nav-below" class="pagination"> 
            <?php 
			previous_post_link( '%link', 'Earlier: %title' );
			next_post_link( '%link', 'Later: %title' );
			?>			
        </div><!-- end #nav-below --> 
		
		</div><!-- end post --> 
		
		<?php endwhile; //end of main post loop ?>
		<?php 
		else: //no posts to show
		
			echo 'Sorry, no posts match your criteria.';
		
		endif; //end if there are posts to show in the loop ?>
        
    </div><!-- end content -->

  <?php get_footer(); ?>
    
