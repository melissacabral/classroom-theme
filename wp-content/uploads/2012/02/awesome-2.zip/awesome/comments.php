<?php
/**
 * The template for displaying Comments.
 * adapted from twenty eleven
 */
?>
	<div id="comments">
	<?php if ( post_password_required() ) : ?>
		<p class="nopassword"><?php _e( 'This post is password protected. Enter the password to view any comments.', 'twentyeleven' ); ?></p>
	</div><!-- #comments -->
	<?php
			/* Stop the rest of comments.php from being processed,
			 * but don't kill the script entirely -- we still have
			 * to fully load the template.
			 */
			return;
		endif;
	?>

	<?php // You can start editing here -- including this comment! ?>

	<?php if ( have_comments() ) : ?>
		<h3 id="comments-title">
			<?php comments_number('No responses', 'One response', '% responses'); ?>
			to
			<?php the_title(); ?>
		</h3>
		
		<?php //if comments are open, show a quick link to the form
		if( comments_open() ){ ?>
			<a href="#respond">Leave a Comment</a>
		<?php }	 ?>
		
		<div class="commentlist">
			<?php
				/* Loop through and list the comments. 
				callback function is in functions.php
				 */
				wp_list_comments( array(
					'avatar_size' => 70,
					'type' => 'comment',
					'style' => 'div',
					'callback' => 'awesome_comment'
				) );
			?>
		</div>

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // are there comments to navigate through ?>
		<div class="pagination">
			<?php previous_comments_link( '&larr; Older Comments' ); ?>
			<?php next_comments_link( 'Newer Comments &rarr;' ); ?>
		</div>
		<?php endif; // check for comment navigation ?>

	<?php
		/* If there are no comments and comments are closed, let's leave a little note, shall we?
		 * But we don't want the note on pages or post types that do not support comments.
		 */
		elseif ( ! comments_open() && ! is_page() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>
		<p class="nocomments">Comments are Closed</p>
	<?php endif; ?>

	<?php comment_form(); ?>

</div><!-- #comments -->
