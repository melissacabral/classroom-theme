<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>;
charset=<?php bloginfo('charset'); ?>" />

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/reset.css" type="text/css" media="screen" />

<?php wp_head(); //IMPORTANT hook for future plugins. Must go in <head> ?>

<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_url'); ?>" />

<title><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title>
</head>

<body <?php body_class(); ?>>
<div id="wrapper" class="clearfix"> <!-- closes in footer.php -->
    <div id="header">
        <h1 class="site-name"><a href="/" title="AwesomeCo" rel="home"> <?php bloginfo('name'); ?> </a></h1>
        <h2 class="site-description"> <?php bloginfo('description'); ?> </h2>
        
		<?php get_search_form(); //show the default search field. override with a file called searchform.php in your theme ?>
		
        <ul class="utilities">
			<?php if( has_nav_menu( 'utilities' ) ){
				wp_nav_menu( array(
					'theme_location' => 'utilities',
					'container' => '',
					'items_wrap' => '%3$s'
									
				) );
				
			}else{
				 wp_list_pages( array(
		   			'title_li' => '',
					'depth' => 1,
					'include' => '2,143',
		   
		   		) ); 
			}?>
        </ul>
		
        <ul class="nav">
			<?php if( has_nav_menu('main-menu') ){
				//if the top nav area has a menu assigned to it, show it
				wp_nav_menu( array(
					'theme_location' => 'main-menu',
					'container' => '',
					'items_wrap' => '%3$s'			
				) );
				
			}else{ 
			//there is no menu assigned, show the normal list pages
			 wp_list_pages( array(
		   			'title_li' => '',
					'depth' => 1,
					'exclude' => '2,143'
		   
		 	 ) ); 
		   } //end if has nav menu ?>
		   
        </ul>
    </div>    <!-- end header -->
	
	
	
	
	