<?php
//turn on featured images for each post
add_theme_support( 'post-thumbnails' ); 

//add image sizes (name, width, height, crop)
add_image_size( 'awesome-thumbnail', 152, 152, true );
add_image_size( 'awesome-frontpage', 960, 330, true );
add_image_size( 'awesome-gallery', 190, 152, true );
add_image_size( 'awesome-widget', 240, 152, true );

//background uploader
add_custom_background();

//turn on editor-style.css
add_editor_style();

//control length of excerpt. default = 55
function awesome_excerpt_length( $length ){
	return 70;	
}
//call the function when WP sets up the default excerpt
add_filter( 'excerpt_length', 'awesome_excerpt_length' );

//customize excerpt [...]
function awesome_read_more( $more ){
	return '<a href="'.get_permalink().'" class="readmore">Read More</a>';
}
add_filter( 'excerpt_more', 'awesome_read_more' );

//add favicon
function awesome_favicon(){
	echo '<link rel="shortcut icon" type="image/x-icon" href="'.get_bloginfo('template_directory').'/images/favicon.ico" />';	
}
add_action( 'wp_head', 'awesome_favicon' );
add_action( 'admin_head', 'awesome_favicon' );

//activate menu areas
function awesome_register_menus(){
	register_nav_menus( array(
		'main-menu' => 'Top Navigation Menu',
		'utilities' => 'Utility (top) Menu'
	) );
}
add_action( 'init', 'awesome_register_menus' );

//register widget areas (dynamic sidebars)
if( function_exists('register_sidebar') ){
	register_sidebar( array(
		'name' => 'Home Page Area',
		'description' => 'The area on the home page, below the content, above the footer.',
		'before_widget' => '<div class="widget %2$s" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
	register_sidebar( array(
		'name' => 'Page Sidebar',
		'description' => 'This area will only appear on pages.',
		'before_widget' => '<div class="widget %2$s" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
	register_sidebar( array(
		'name' => 'Blog Sidebar',
		'description' => 'This area appears on blog archive views.',
		'before_widget' => '<div class="widget %2$s" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );	
	register_sidebar( array(
		'name' => 'Footer',
		'description' => 'Will appear at the bottom of every view.',
		'before_widget' => '<div class="widget %2$s" id="%1$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'
	) );
}

//Custom Comment Callback. Used in comments.php
function awesome_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <div <?php comment_class('clearfix'); ?> id="comment-<?php comment_ID() ?>">
      <div class="comment-author vcard">
         <?php echo get_avatar( $comment->comment_author_email, 70 ); ?>

         <span class="fn"><?php comment_author_link(); ?></span>
      </div>
      <?php if ($comment->comment_approved == '0') : ?>
         <em><?php _e('Your comment is awaiting moderation.') ?></em>
         <br />
      <?php endif; ?>
	  
	<?php comment_text() ?>

      <div class="comment-meta commentmetadata">
	  	<span class="comment-date">
			<?php comment_date('F j, Y'); ?>
		</span>
		
		<span class="comment-link">
			<a href="<?php comment_link(); ?>">Link</a>
		</span>
		
		<span class="reply">
         <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
      	</span>
	  
	  </div> <!-- closes comment-meta -->

<?php //no need to close the last div, WP will do it for you.
} //end custom comment function


// enable threaded comments
function enable_threaded_comments(){
    if ( (!is_admin())  && is_singular() AND comments_open() AND (get_option('thread_comments'))){
            wp_enqueue_script('comment-reply');
        } 
  
}
add_action('wp_print_scripts', 'enable_threaded_comments');

//change comment count to include ONLY comments
add_filter('get_comments_number', 'my_comment_count');

// TODO: come back later and put comments on this
function my_comment_count( $count ) {
    global $id;
    $comments = get_approved_comments($id);
    $comment_count = 0;
    foreach($comments as $comment){
        if($comment->comment_type == ""){
            $comment_count++;
        }
    }
    return $comment_count;
}

//breadcrumbs "plugin"
function dimox_breadcrumbs() {
 
  $delimiter = '&raquo;';
  $home = 'Home'; // text for the 'Home' link
  $before = '<span class="current">'; // tag before the current crumb
  $after = '</span>'; // tag after the current crumb
 
  if ( !is_home() && !is_front_page() || is_paged() ) {
 
    echo '<div id="crumbs">';
 
    global $post;
    $homeLink = get_bloginfo('url');
    echo '<a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' ';
 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $before . 'Archive by category "' . single_cat_title('', false) . '"' . $after;
 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('d') . $after;
 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('F') . $after;
 
    } elseif ( is_year() ) {
      echo $before . get_the_time('Y') . $after;
 
    } elseif ( is_single() && !is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';
        echo $before . get_the_title() . $after;
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
        echo $before . get_the_title() . $after;
      }
 
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo $before . $post_type->labels->singular_name . $after;
 
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
      echo $before . get_the_title() . $after;
 
    } elseif ( is_page() && !$post->post_parent ) {
      echo $before . get_the_title() . $after;
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $before . get_the_title() . $after;
 
    } elseif ( is_search() ) {
      echo $before . 'Search results for "' . get_search_query() . '"' . $after;
 
    } elseif ( is_tag() ) {
      echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after;
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $before . 'Articles posted by ' . $userdata->display_name . $after;
 
    } elseif ( is_404() ) {
      echo $before . 'Error 404' . $after;
    }
 
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    }
 
    echo '</div>';
 
  }
} // end dimox_breadcrumbs()
