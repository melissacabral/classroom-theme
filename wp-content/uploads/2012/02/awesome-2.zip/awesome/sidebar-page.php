<?php /*

		Template to display a special sidebar only on pages
		
*/ ?>
 
  <div id="sidebar">
  <?php
  //is this page a child page?
  if($post->post_parent){
	  //get the siblings
  	$children = wp_list_pages("title_li=&child_of=".$post->post_parent."&echo=0&depth=-1");
  }else{ //get the children of this page
  	$children = wp_list_pages("title_li=&child_of=".$post->ID."&echo=0&depth=-1");
  }
  if ($children) { ?>
  <div class="widget">
      <h3>More In <?php the_title(); ?></h3>
	  <ul>
	  <?php echo $children; ?>
	  </ul>
  </div>
  <?php } ?>
  
  <?php 
	//check to see if home widget area does not exist or have any widgets
	if(!dynamic_sidebar('Page Sidebar')){
		//alternate content here
	}
	?>
</div><!-- end sidebar --> 