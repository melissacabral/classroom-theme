<?php 
/*
	File to display product archive by Brand
*/
?>
<?php get_header(); ?>
    
    <div id="content"> 
	
	<?php
	//turn on breadcrumbs if the function exists
	if( function_exists( 'dimox_breadcrumbs' ) ){
		//TODO:  patch breadcrumb script so it works with taxos
		//dimox_breadcrumbs();
	}
	 ?>
	      
       
       <?php //main loop
	   if( have_posts() ):
	    ?>
		<h2 class="archive-title"> All products featuring <?php single_cat_title(); ?></h2>
		
		<?php while( have_posts() ): the_post(); ?>
        
        <div id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?>>
			<?php 
			//check for thumbnail
			if( has_post_thumbnail() ){
				the_post_thumbnail('awesome-thumbnail');
			} ?>           
           
		   
		   	<h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>		
							
				
			<?php the_excerpt(); ?>			
		
		</div><!-- end post --> 
		
		<?php endwhile; //end of main post loop ?>
		<?php 
		else: //no posts to show
		
			echo 'Sorry, no posts match your criteria.';
		
		endif; //end if there are posts to show in the loop ?>
        
    </div><!-- end content -->
	
<?php get_sidebar( 'product' ) ?>
<?php get_footer(); ?>
    
