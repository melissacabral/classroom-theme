<?php get_header(); ?>
    
	<?php
	//if this page has a featured image
	if( has_post_thumbnail() ){
		the_post_thumbnail( 'awesome-frontpage' );		
	}
	
	 ?>
	
    <div id="content"> 
	
	<?php //get the option values
	$options = get_option('rad_options'); 
	//only show the quote if the box was checked
	if( $options['show_message'] == 1 ){?>
	<blockquote>
		<p><?php echo $options['welcome_message']; ?></p>
		<cite><?php echo $options['message_source']; ?></cite>	
	</blockquote>
	<?php } ?>
	
	
	     
       
       <?php //main loop
	   if( have_posts() ):
	    ?>
		
		<?php while( have_posts() ): the_post(); ?>
        
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h2 class="entry-title">  <?php the_title(); ?> </h2>                 
            
            <div class="entry-content">
				
                	<?php the_content(); ?>
				
            </div>
        </div><!-- end post --> 
		
		<?php endwhile; //end of main post loop ?>
		
		
		<?php 
		else: //no posts to show
		
			echo 'Sorry, no posts match your criteria.';
		
		endif; //end if there are posts to show in the loop ?>
        
    </div><!-- end content -->
	
	<?php 
	//check to see if home widget area does not exist or have any widgets
	if(!dynamic_sidebar('Home Page Area')){
		//alternate content here
	}
	?>
    
 
  <?php get_footer(); ?>
    
