<?php 
/*
Plugin Name: Simple widget with one option
Plugin URI: http://wordpress.melissacabral.com
Description: Just an example for later development!
Version: 1
Author: Melissa Cabral
Author URI: http://melissacabral.com
License: GPL
*/

//tell WP the widget exists. replace Rad_Simple_Widget with your class name
function rad_register_simple_widget(){
	register_widget('Rad_Simple_Widget');	
}
add_action( 'widgets_init', 'rad_register_simple_widget' );

//build the widget class. class name must match the first function name (constructor)
class Rad_Simple_Widget extends WP_Widget{
	//widget options and settings
	function Rad_Simple_Widget(){
		$widget_ops = array(
			//make up the classname, keep it unique
			'classname' => 'widget-rad-simple',
			'description' => 'A simple widget with just a title'
		);
		$control_ops = array(
			//will become 'id="rad-simple-widget-1"' in final output
			'id_base' => 'rad-simple-widget',
			'width' => '400'
		);
		//feed these settings into WP_Widget(id-base, title, widget ops, control ops)
		$this->WP_Widget('rad-simple-widget', 'Simple Widget', $widget_ops, $control_ops );
	}
	
	//REQUIRED - widget. how the widget will display on the front-end. HTML is OK!
	function widget( $args, $instance ){
		//pull out all the settings of this widget
		extract( $args );
		
		//get each variable from the form. if there are more fields, add them here. title is special and needs a filter
		$title = apply_filters( 'widget_title', $instance['title']);
		//$field = $instance['field'];
		
		//display the widget! $before and $after vars are all defined in the theme and must be used!
		echo $before_widget;
		
		//if title exists, show it with the right markup from the theme
		if( $title )
			echo $before_title . $title . $after_title;	
			
		//more MEAT goes here
		echo '<p>This is my widget meat!</p>';	
		
		echo $after_widget;
	}//end widget function
	
	//REQUIRED - update. Used to clean up data and save the new info over the old
	function update( $new_instance, $old_instance ){
		$instance = $old_instance;
		
		//clean up each field with kses
		$instance['title'] = wp_filter_nohtml_kses( $new_instance['title'] );
		//add more fields here
		
		//return the cleaned up instance
		return $instance;
	}
	//OPTIONAL - form. builds the inputs in the admin panel
	function form( $instance ){
		//set up default settings for each field
		$defaults = array(
			'title' => ''
			//add more fields here
		);
		
		//merge the form values with the defaults. use as is
		$instance = wp_parse_args( (array) $instance, $defaults );
		?>
		
		<!-- HTML for the interior of the form goes here -->
		<label for="<?php echo $this->get_field_id( 'title' ) ?>">Title:</label>
		
		<input type="text" name="<?php echo $this->get_field_name( 'title' ) ?>" id="<?php echo $this->get_field_id( 'title' ) ?>" value="<?php echo $instance['title']; ?>" />
		<!-- do not include the save button, wp will take care of it -->
		<?php
	}
	
}
