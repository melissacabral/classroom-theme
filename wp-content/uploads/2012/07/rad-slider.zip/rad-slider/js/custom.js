jQuery(document).ready(function() {
	jQuery.noConflict();
	jQuery('#rad-slider ul').cycle({
		fx: 'fade',
		next: '#next-slide',
		prev: '#previous-slide'	
 	});
});