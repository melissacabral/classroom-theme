<?php get_header(); ?>
    
    <div id="content">
	<?php 
	if( function_exists('dimox_breadcrumbs') ):
		dimox_breadcrumbs();
	endif; 
	?>
	
	<?php 
	//THE LOOP.
	if( have_posts() ): 
		while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
			<?php if( has_post_thumbnail() ): ?>
				<div class="image alignright">
					<?php the_post_thumbnail( 'medium' ); ?>
				</div>
			<?php else: ?>	
				<span class="nophoto">photo coming soon</span>
			<?php endif; ?>
		
			<div class="product-info">
				<h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> 
					<?php the_title(); ?> 
				</a></h2>           
				
				<div class="entry-content">
					<?php the_content(); ?>
				</div><!-- end entry-content -->
				
				 <div class="postmeta"> 
					<?php the_meta(); //shows all custom fields ?>
					
				<ul class="post-meta">
				<?php 
				//the_terms(id, taxonomy, before list, between items, after list)
				
				the_terms( $post->ID, 'brand', '<li>Brand: ', ', ', '</li>'); 
				
				the_terms( $post->ID, 'feature', '<li>Features: ', ', ', '</li>');?>
				</ul>
				</div><!-- end postmeta -->
		   </div><!-- end product-info -->
        
	
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>
	          
        
        <div id="nav-below" class="pagination"> 
            <?php 
			//links to the next or prev post titles
			previous_post_link('%link', 'Earlier: %title');
			next_post_link('%link', 'Later: %title');
			 ?>
        </div><!-- end #nav-below --> 
        
    </div><!-- end content -->
    
<?php get_sidebar('shop'); ?> 
<?php get_footer(); ?>  