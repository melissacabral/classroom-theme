<aside id="sidebar">
<?php
if( ! dynamic_sidebar('Page Sidebar') ):
endif;
?>
</aside>