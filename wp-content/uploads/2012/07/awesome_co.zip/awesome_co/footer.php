</div><!-- end wrapper -->

<footer class="clearfix" id="colophon" role="contentinfo">
    <div class="widget-container">        
        <?php if( ! dynamic_sidebar('Footer Area') ):
		
		//alternate content to the footer widgets could go here if needed
		
			  endif; ?>
		       
    </div>
</footer><!-- end footer -->

<?php 
//must call wp_footer right before </body> for JS and plugins to run!
wp_footer();  ?>
</body>
</html>