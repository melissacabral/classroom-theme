<?php get_header(); ?>
    
    <div id="content">
	
	<?php if( has_post_thumbnail() ): ?>
	<div class="banner-image">
		<?php the_post_thumbnail('awesome-banner'); ?>
	</div>	
	<?php endif; ?>
	
	<?php 
	//THE LOOP.
	if( have_posts() ): 
		while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
                  
     		 <div class="entry-content">
                <?php the_content(); ?>
            </div>
       
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>
  
    </div><!-- end content -->
    
<?php 
//includes sidebar-home.php
get_sidebar('home'); ?> 
<?php get_footer(); ?>  