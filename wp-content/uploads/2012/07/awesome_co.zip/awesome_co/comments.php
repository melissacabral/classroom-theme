<?php
//this file will run wherever comments_template() is called. 
?>
<div class="comments">
<?php  //check to see if there are comments
	if( have_comments() ): ?>
		<h3>
<?php comments_number('No Responses to ', 'One Response to ', '% Responses to ') ?> 
		<?php the_title(); ?>
		
		<?php
		//if comments are allowed on this post, provide a quick link to leave a comment
		if( comments_open() ): ?>
			| <a href="#respond">Leave a Comment</a>	
		<?php endif; ?>
		</h3>
		
		<div class="commentlist">
			<?php 
			//THE COMMENT LOOP:
			wp_list_comments(array(
				'type' => 'comment',
				'style' => 'div',
				'callback' => 'awesome_comment'
			)); ?>
		</div>
		
			<?php  
			//show comment pagination if the option for paged comments is on and there are more than one page of comments to show
			if( get_option( 'page_comments' ) AND get_comment_pages_count() > 1 ):			
			 ?>
			<div class="pagination">
				<?php previous_comments_link('&larr; Older Comments'); ?>
				<?php next_comments_link('Newer Comments &rarr;'); ?>
			</div>
			<?php endif; //paged comments ?>
		
		<?php endif; //have comments ?>
		
		
		<?php 
		//if there are trackbacks or pingbacks, show them
		$trackbacks = get_comments(array( 
			'type' => 'pings',
			'post_id' => $post->ID
		 ));
		$trackbacks_number = count($trackbacks);
		//at least one trackback exists
		if( $trackbacks_number >= 1 ): 
		?>
		<div class="trackbacks">
			<h3><?php echo $trackbacks_number ?> Sites link here:</h3>
			
			<?php wp_list_comments(array(
				'type' => 'pings',
				'style' => 'div',
				'per_page' => 100,
				'page' => 1
				
			)); ?>
			
		</div>
		<?php endif; //there are trackbacks ?>
		

	<?php comment_form(); ?>
	
	<?php 
		if( !comments_open AND !is_page() ): ?>
		
		<p class="nocomments">Comments are closed</p>
			
	<?php endif;
	 ?>

</div>
 
 