<?php get_header(); ?>
    
    <div id="content">
	<?php 
	if( function_exists('dimox_breadcrumbs') ):
		dimox_breadcrumbs();
	endif; 
	?>
	
	<?php 
	//THE LOOP.
	if( have_posts() ): ?>
	
	<h2 class="archive-title"> All Products Featuring <?php single_cat_title(); ?></h2>
	
	<?php while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
            <h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> 
				<?php the_title(); ?> 
			</a></h2>
			<?php 
			if( has_post_thumbnail() ):
			 ?>
			<div class="thumbnail">
			 	<?php the_post_thumbnail('thumbnail'); ?>
			</div>
			<?php endif; ?>            
            
           <?php the_excerpt(); ?>
         
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>
	          
        
        <div id="nav-below" class="pagination"> 
            <?php 
			//make sure the plugin is running before calling it
			if( function_exists('wp_pagenavi') ):
				wp_pagenavi();
			else:			
				next_posts_link('&larr; Older Posts');
				previous_posts_link('Newer Posts &rarr;');	
			endif;		
			?>
        </div><!-- end #nav-below --> 
        
    </div><!-- end content -->
    
<?php get_sidebar('shop'); ?> 
<?php get_footer(); ?>  