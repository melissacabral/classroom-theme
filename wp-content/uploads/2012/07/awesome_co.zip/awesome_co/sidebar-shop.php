<aside id="sidebar">
	<div class="widget">
		<h3>Filter by Feature:</h3>
		<?php wp_tag_cloud( array(
			'taxonomy' => 'feature',
			'smallest' => 12,
			'largest' => 16
		) ); ?>
		
	</div>
	
	<div class="widget">
		<h3>Filter by Brand:</h3>
		<ul>
			<?php wp_list_categories( array(
				'taxonomy' => 'brand',
				'title_li' => ''
			) ); ?>
		</ul>
	</div>
	
</aside>