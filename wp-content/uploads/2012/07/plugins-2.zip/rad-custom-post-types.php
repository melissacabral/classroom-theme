<?php
/*
Plugin Name: Custom Post Types
Description:  Adds products and their taxonomies to our site
Plugin URI: http://yoursite.com
Author: Melissa Cabral
Version: 1.0
License: GPLv2
Author URI: http://melissacabral.com
*/

function rad_create_post_type(){
	register_post_type( 'product', array(
		'labels' => array(
			'name' => 'Products',
			'singular_name' => 'Product',
			'not_found' => 'No Products Found',
			'add_new_item' => 'Add New Product'
		),
		'public' => true,
		'has_archive' => true,
		'rewrite' => array( 'slug' => 'products' )
	) );
	
	//turn on admin panel features for this post type
	$supports = array('thumbnail', 'custom-fields', 'comments', 'revisions', 'page-attributes', 'author', 'excerpt');
	add_post_type_support( 'product', $supports );
	
	//create hierarchical taxo for product brands
	register_taxonomy( 'brand', 'product', array(
		'labels' => array(
			'name' => 'Brands',
			'singular_name' => 'Brand',
			'add_new_item' => 'Add New Brand',
			'search_items' => 'Search Brands',
			'parent_item' => 'Parent Brand',
			'update_item' => 'Update Brand'
		),
		'rewrite' => array( 'slug' => 'brands'),
		'hierarchical' => true
	));
	
	register_taxonomy( 'feature', 'product', array(
		'labels' => array(
			'name' => 'Features',
			'singular_name' => 'Feature',
			'add_new_item' => 'Add New Feature',
			'search_items' => 'Search Features',
			'update_item' => 'Update Feature'
		),
		'rewrite' => array( 'slug' => 'features'),
		'hierarchical' => false
	));
}

add_action( 'init', 'rad_create_post_type' );

// ----------------------------------------------
//
//		REWRITE TO PREVENT 404 ERRORS
//
// always run flush_rewrite_rules in conjunction 
// with the creation of custom post types and taxos
// or you will experience 404s! 
// this will re-create .htaccess file.
// your site must use "pretty" permalinks  
// -----------------------------------------------
function rad_flush_rules(){
	rad_create_post_type();
	flush_rewrite_rules();	
}
//run it when the plugin is turned on
register_activation_hook( __FILE__ , 'rad_flush_rules');





