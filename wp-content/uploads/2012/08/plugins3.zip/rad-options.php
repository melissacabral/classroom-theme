<?php /*
Plugin Name: Rad Options
Plugin URI: http://wordpress.melissacabral.com
Description: Adds an options page for "global custom fields"
Version: 1
Author: Melissa Cabral
Author URI: http://melissacabral.com
License: GPL
*/

//setup menu in admin panel
function rad_options_add_page(){
	//			title, menu label, user capability, page slug for url, form callback
	add_options_page('Company Info', 'Company Info', 'manage_options', 'company-info', 'rad_options_build_form');	
}
add_action('admin_menu', 'rad_options_add_page');

//register the settings - whitelist the options so WP knows it exists
function rad_options_register(){
	register_setting('rad_options_group', 'rad_options', 'rad_options_validate');	
}
add_action('admin_init', 'rad_options_register');

//callback to create the form (must match the last arg above)
function rad_options_build_form(){ ?>
	<div class="wrap">
		<h2>Company Info</h2>
		<form method="post" action="options.php">
		<?php settings_fields('rad_options_group'); 
			//prefill the form - get the current values from the DB
			$values = get_option('rad_options');
		 ?>
			<label>Company Phone:</label><br />
			<input type="text" name="rad_options[company_phone]" value="<?php 
				echo $values['company_phone'];  ?>" size="45" />
			<br /><br />
			<label>Contact Email:</label><br />
			<input type="text" name="rad_options[contact_email]" value="<?php
				echo $values['contact_email']; ?>" size="45" />
			<br /><br />
			<label>Company Address</label><br />
			<textarea name="rad_options[company_address]" cols="45" rows="5"><?php 
			echo $values['company_address']; ?></textarea>
			<br /><br />
			<h3>Welcome Message</h3>
			<input type="checkbox" name="rad_options[show_message]" value="1" <?php 
			checked($values['show_message'], 1); ?> />
			<label>Show the welcome message on the front page</label>
			<br /><br />
			<label>Message (Quote):</label><br />
			<textarea name="rad_options[message]" cols="45" rows="5"><?php 
			echo $values['message']; ?></textarea>
			<br /><br />
			<label>Quote Source:</label><br />
			<input type="text" name="rad_options[quote_source]" value="<?php 
			echo $values['quote_source']; ?>" size="45" />	
			<br /><br />
			<input type="submit" value="Save Company Info" class="button-primary" />		
		</form>
	</div>	
<?php }

//sanitization callback. must match above
function rad_options_validate($input){
	//remove all tags and evil scripts from some inputs
	$input['company_phone'] = wp_filter_nohtml_kses($input['company_phone']);
	$input['contact_email'] = wp_filter_nohtml_kses($input['contact_email']);
	$input['quote_source'] = wp_filter_nohtml_kses($input['quote_source']);
	
	//HTML tags that are safe for some fields
	$allowed_tags = array(
		'br' => array(),
		'p' => array(),
		'a' => array(
			'href' => array(),
			'title' => array()
		)
	);
	$input['company_address'] = wp_kses($input['company_address'], $allowed_tags);
	$input['message'] = wp_kses($input['message'], $allowed_tags);
	
	//check to see if show_message is checked, if so, keep the value of 1, else set value to 0 (prevents NULL value when unchecked)
	$input['show_message'] = ( $input['show_message'] == 1 ? 1 : 0 );
	
	//send the cleaned up value back to the parser
	return $input;
}
