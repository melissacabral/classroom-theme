// JavaScript Document
//replace $ with jQuery (noConflict wrapper)
jQuery(document).ready(function(){
	jQuery.noConflict();
	//selector = parent container of all slides
	jQuery('#rad-slider ul').cycle({
			fx: 'scrollHorz',
			next: '#next-slide',
			prev: '#previous-slide'	
		});
})