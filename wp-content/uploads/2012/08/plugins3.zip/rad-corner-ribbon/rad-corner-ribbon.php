<?php 
/*
Plugin Name: Subscribe to Updates Ribbon
Description:  Adds a ribbon to the corner of the screen that links to the feed. 
Plugin URI: http://yoursite.com
Author: Melissa Cabral
Version: 1.0
License: GPLv2
Author URI: http://melissacabral.com
*/

function rad_ribbon_display(){
	//dynamic path to ribbon image. first argument is a path relative to this file, second argument is the location of this file. always use the __FILE__ constant. 
	$image_path = plugins_url( 'images/corner-ribbon.png', __FILE__ );	
	?>
	<a href="<?php bloginfo('rss2_url') ?>" id="rad_corner_ribbon">
	<img src="<?php echo $image_path ?>" alt="subscribe now" />
	</a>
<?php	
}

add_action( 'wp_footer', 'rad_ribbon_display' );


//register and queue the stylesheet
function rad_stylesheet(){
	$stylesheet_path = plugins_url( 'rad-style.css', __FILE__);
	//custom stylesheets need to be registered first (name, path)
	wp_register_style( 'rad-style', $stylesheet_path );
	//then, put it in line with the other stylesheets (name)
	wp_enqueue_style( 'rad-style' );
}

add_action( 'wp_enqueue_scripts', 'rad_stylesheet' );





//no close php!