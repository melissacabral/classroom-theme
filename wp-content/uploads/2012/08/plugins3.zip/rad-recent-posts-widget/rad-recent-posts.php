<?php /*
Plugin Name: Recent Posts Widget 
Plugin URI: http://wordpress.melissacabral.com
Description: Shows a customizable list of posts with thumbnails in a widget
Version: 1
Author: Melissa Cabral
Author URI: http://melissacabral.com
License: GPL
*/

//create a custom image size for the thumb
function rad_recent_image_size(){
	add_image_size( 'rad_recent_image', 94, 70, true );	
}
add_action('admin_init', 'rad_recent_image_size');

//register and run the stylesheet
function rad_recent_style(){
	//get path to stylesheet
	$style_path = plugins_url('css/recent-posts.css', __FILE__);
	wp_register_style('rad_recent_stylesheet', $style_path);
	wp_enqueue_style('rad_recent_stylesheet');	
}
add_action('wp_enqueue_scripts', 'rad_recent_style');





//tell wordpress that our widget needs to exist
function rad_recent_register_widget(){
	register_widget('Rad_Recent_Simple_Widget');	
}
add_action('widgets_init', 'rad_recent_register_widget');

//Our new widget is a copy of the WP_Widget object class
class Rad_Recent_Simple_Widget extends WP_Widget{
	//give the first function the same name as the class
	function Rad_Recent_Simple_Widget(){
		//Widget Settings
		$widget_ops = array(
			'classname' => 'widget-recent-post-thumbs',
			'description' => 'A list of recent posts with thumbnails'			
		);
		//Widget Control Settings
		$control_ops = array(
			//necessary for multiple instances of the widget to work. WP will append a unique number to the end of the ID base
			'id_base' => 'recent-post-widget',
			'width' => 400
		);
		//WP_Widget(id-base, name, widget ops, control ops)
		$this->WP_Widget('recent-post-widget', 'Recent Posts with Thumbs', $widget_ops, $control_ops);
	}
	//Front end display (always use 'widget')
	function widget( $args,  $instance ){
		//args contains all the settings defined when the widget area was registered 
		//(see theme functions.php)
		extract($args); 
		
		//make this title filter-able
		$title = apply_filters( 'widget-title', $instance['title'] ); 
		//retrieve the other normal fields
		$number = $instance['number'];
		$show_excerpt = $instance['show_excerpt'];
		
		//Widget output begins
		echo $before_widget;
		
		//show the title if the user filled one in
		if($title):
			echo $before_title . $title . $after_title;
		endif;
		
		//custom loop to get recent posts
		$custom_query = new WP_Query( array(
			'showposts' => $number,
			'ignore_sticky_posts' => 1,
			'orderby' => 'post_date',
			'order' => 'desc'
		) );
		?>
		<ul>
		<?php while( $custom_query -> have_posts() ):
				$custom_query -> the_post();
		 ?>
			<li>
			<a href="" class="thumbnail-link">
				<?php
				if( has_post_thumbnail() ):
					the_post_thumbnail('rad_recent_image');
				else:
					echo '<img src="http://placepuppy.it/94/70" />';
				endif;
				
				 ?>
				<span class="zoom"></span>
			</a>
			<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
			
			<?php 
			if($show_excerpt == 1):
				the_excerpt(); 
			endif;
			?>
			
			</li>
			<?php endwhile; 
			//must reset after custom query!
			wp_reset_query();?>
			
		</ul>
		<?php 
		echo $after_widget;
	}
	
	//handle saves and widget locations. always use 'update'
	function update( $new_instance, $old_instance ){
		$instance = $old_instance;
		
		//strip evil scripts from all fields
		$instance['title'] = wp_filter_nohtml_kses($new_instance['title']);
		$instance['number'] = wp_filter_nohtml_kses($new_instance['number']);
		$instance['show_excerpt'] = ( $new_instance['show_excerpt'] == 1 ? 1 : 0 ); 
		//more fields go here
	
		return $instance;
		
	}
	
	//optional function for the admin form
	function form( $instance ){
		//set up default settings for each field
		$defaults = array(
			'title' => 'Recent Posts',
			'number' => 5,
			'show_excerpt' => 1
		);
		
		//merge defaults with the form values
		$instance = wp_parse_args( (array) $instance, $defaults );
		
		//HTML time!
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
			<input type="text" name="<?php echo $this->get_field_name('title') ?>" id="<?php echo $this->get_field_id('title');
			?>" style="width:100%" value="<?php echo $instance['title'] ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('number'); ?>">Number of Posts:</label>
			<input type="text" name="<?php echo $this->get_field_name('number') ?>" id="<?php echo $this->get_field_id('number');
			?>" style="width:25%" value="<?php echo $instance['number'] ?>" />
		</p>
		
		<p>
			<input type="checkbox" name="<?php echo $this->get_field_name('show_excerpt'); ?>" id="<?php echo $this->get_field_id('show_excerpt'); ?>" value="1" <?php 
			checked($instance['show_excerpt'], 1); ?> />
			<label for="<?php echo $this->get_field_id('show_excerpt'); ?>">
			Show excerpt for each post
			</label>
		</p>
		<?php
	}	
}




