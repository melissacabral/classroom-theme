<aside id="sidebar">
<?php
if( ! dynamic_sidebar('Home Sidebar') ):
endif;
?>
</aside>