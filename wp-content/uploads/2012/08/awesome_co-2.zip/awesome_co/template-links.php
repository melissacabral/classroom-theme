<?php 
/*
Template Name: Links List
*/
?>
<?php get_header(); ?>
    
    <div id="content">
	<?php 
	if( function_exists('dimox_breadcrumbs') ):
		dimox_breadcrumbs();
	endif; 
	?>
	<?php 
	//THE LOOP.
	if( have_posts() ): 
		while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
            <h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> 
				<?php the_title(); ?> 
			</a></h2>       
            
            <div class="entry-content">
                <?php the_content(); ?>
                
               
                <?php //shows everything created in admin>links
				//cat_before and after is to remove the <li> wrapper from categories
				//title_ before and after changes the <h2> (default) to <h3>
				//lots more args in the codex!!!!!
				wp_list_bookmarks( array(
					'category_before' => '<div class="%class">',
					'category_after' => '</div>',
					'title_before'  => '<h3>',
    				'title_after'  => '</h3>'
				) );  
				?>
              
            </div>
       
        
		
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>
	          
        
        <div id="nav-below" class="pagination"> 
            <a href="/blog/page/2/" >&larr; View Older Posts</a> 
        </div><!-- end #nav-below --> 
        
    </div><!-- end content -->
    
<?php get_sidebar(); ?> 
<?php get_footer(); ?>  