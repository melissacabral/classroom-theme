<?php get_header(); ?>
    
    <div id="content">
	
	<?php
	//Check to see if the plugin function exists before running it. 
	//Prevents Fatal Errors when the plugin is turned off.
	if( function_exists('rad_show_slider') ):
		rad_show_slider();		
	endif; ?>
	
	
	<?php //show the quote from rad_options
	$options = get_option('rad_options'); ?>
	
	<?php if($options['show_message'] == 1): ?>
		<blockquote class="home-quote">
			<?php 
			echo $options['message']; ?>
			
			<cite><?php echo $options['quote_source'] ?></cite>
		</blockquote>
	<?php endif; ?>
	
	
	<?php 
	//THE LOOP.
	if( have_posts() ): 
		while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
                  
     		 <div class="entry-content">
                <?php the_content(); ?>
            </div>
       
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>
  
    </div><!-- end content -->
    
<?php 
//includes sidebar-home.php
get_sidebar('home'); ?> 
<?php get_footer(); ?>  