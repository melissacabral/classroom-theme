<?php
/*
Plugin Name: Custom Post Type Setup
Plugin URI: http://wordpress.melissacabral.com
Description: Adds the Product custom post type
Author: Melissa Cabral
Version: 1.0
License: GPLv2
Author URI: http://melissacabral.com
*/

function rad_create_cpt(){
	//tell WP that our post type needs to exist. this will create admin interface for the CPT
	register_post_type( 'product', array(
		'labels' => array(
			'name' => 'Products',
			'singular_name' => 'Product',
			'add_new_item' => 'Add New Product',
			'not_found' => 'No Products Found'
		),
		'public' => true,
		'has_archive' => true,
		'rewrite' => array( 'slug' => 'products' )
	) );
	
	//turn on admin panel features
	$supports = array('thumbnail', 'custom-fields', 'revisions', 'excerpt', 'author');
	add_post_type_support('product', $supports);
	
	//register taxonomy - Brand
	register_taxonomy( 'brand', 'product', array(
		'labels' => array(
			'name' => 'Brands',
			'singular_name' => 'Brand',
			'add_new_item' => 'Add New Brand',
			'search_items' => 'Search Brands',
			'parent_item' => 'Parent Brand',
			'update_item' => 'Update Brand'
		),
		'hierarchical' => true, //parent/child, like categories
		'rewrite' => array( 'slug' => 'brands' )
	) );
	
	//register taxonomy - Features
	register_taxonomy( 'feature', 'product', array(
		'labels' => array(
			'name' => 'Features',
			'singular_name' => 'Feature',
			'add_new_item' => 'Add New Feature',
			'search_items' => 'Search Features',
			'parent_item' => 'Parent Feature',
			'update_item' => 'Update Feature'
		),
		'hierarchical' => false,  //flat, like tags
		'rewrite' => array( 'slug' => 'features' )
	) );	
	
}
//run it when WP initializes
add_action( 'init', 'rad_create_cpt' ); 


//This prevents 404 errors when viewing our custom post archives
//always do this whenever introducing a new post type or taxonomy
function rad_rewrite_flush(){
	rad_create_cpt();
	flush_rewrite_rules();
}
//run this when the plugin activates
register_activation_hook(__FILE__, 'rad_rewrite_flush');
