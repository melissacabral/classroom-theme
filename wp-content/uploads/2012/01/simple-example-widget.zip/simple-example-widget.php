<?php 
/*
Plugin Name: Simple example widget
Plugin URI: http://wordpress.melissacabral.com
Description:  really basic, for future development!
Author: Melissa
Author URI: http://melissacabral.com
Version: 1.0
License: GPLv2
*/

//register our widget so WP recognizes it
function register_simple_widget(){
	register_widget('Rad_Simple_Widget');	
}
//when widgets are initialized, run the register function. always use widgets_init hook
add_action('widgets_init', 'register_simple_widget');

//create our widget class. make sure the name matches what we registered above
class Rad_Simple_Widget extends WP_Widget{
	function Rad_Simple_Widget(){
		//widget settings
		$widget_ops = array(
			'classname' => 'widget-simple',
			'description' => 'The simplest widget with just a title'
		);
		$control_ops = array(
			'id_base' => 'simple-widget'
		);
		//apply settings and create the widget (id_base, title, widget ops, control ops)
		$this->WP_Widget( 'simple-widget', 'Simplest Widget Ever', $widget_ops, $control_ops );
	}
	
	// FRONT END DISPLAY. always use function widget( $args, $instance )
	function widget( $args, $instance ){
		extract($args);
		
		//variables from the form
		$title = apply_filters('widget_title', $instance['title']);
		//example of other fields
		//$name = $instance['name'];
		
		//output "before widget" defined by the theme in register_sidebars
		echo $before_widget;
		
		//show the title if it is not blank
		if($title) echo $before_title . $title . $after_title;
		?>
		MEAT GOES HERE. maybe some HTML? maybe a picture of grandma?
		<?php 
		
		echo $after_widget;
	}
	
	//Update settings when user hits save. always use function update($new_instance, $old_instance)
	function update($new_instance, $old_instance){
		$instance = $old_instance;
		
		//sanitize all fields
		$instance['title'] = wp_filter_nohtml_kses($new_instance['title']);
		//example of other fields
		//$instance['name'] = wp_filter_nohtml_kses($new_instance['name']);
		
		return $instance;
	}
	
	//create the form for the admin panel. always use function form( $instance )
	function form( $instance ){
		//set up defaults
		$defaults = array(
			'title' => ''
		);
		//merge defaults with other fields
		$instance = wp_parse_args((array) $instance, $defaults);
		
		//actual form display ?>
		<p>
	<label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
			
	<input type="text" name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo $instance['title']; ?>" style="width:100%" />
		</p>
		
	<?php }
		
} //end class constructor