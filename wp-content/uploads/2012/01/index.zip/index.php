<?php get_header(); ?>
	
	<div id="content">
	
		<?php
		//basic loop
		//if there are posts to show
		if ( have_posts() ) :
		?>
		<?php while( have_posts() ) : the_post(); ?>
		 
		<div <?php post_class( array('clearfix') ); ?>  >
			<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			
			<div class="post-meta">
				<span class="author">
					<?php the_author(); ?>
				</span>
				<span class="date">
					<?php the_date(); ?>
				</span>
				<span class="num-comments">
					 <?php comments_number( 'no comments', 'one comment', '% comments' ); ?>
				</span>
				<span class="tags">
					<?php the_tags(); ?>
				</span>
			</div><!-- end post-meta -->	
			
			<?php
			//if the post has a thumbnail, show it with one category name on top of it
			if(has_post_thumbnail()){
			 ?>
			<div class="thumbnail">
				<?php the_post_thumbnail('awesome-thumb'); ?>
				
				<?php 
				//make sure the current post/page has a category
				if(has_category()){ ?>
					<h3 class="category">
					<?php 
						//what category is it in.. as a list
						$category = get_the_category(); 
						//show the first one, in a link to the category archive
						echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
						?>
					</h3>
                <?php } ?>
				
			</div><!-- end thumbnail -->
			<?php } //end if has post thumb ?>
			
			<div class="entry-content">
			
			<?php 
			//if viewing a single post or page, show the full content
			if( is_single() || is_page() ){ ?>
				
				<?php the_content(); ?>
				<?php 
				//show pagination on the post, if viewing a paginated post!
				wp_link_pages( array( 
					'before' => '<div class="page-link pagination"><span>Continue Reading:</span>', 
					'after' => '</div>',
					'next_or_number' => 'number'
				) ); ?>
				
			<?php }else{  //not single post or page, show just a short excerpt ?>
				<?php the_excerpt(); ?>
			<?php } ?>
				
				
			</div>
			
		
		</div><!-- end post -->
		
		<?php endwhile; ?>
		<?php endif;?>
	
	</div><!-- end content -->
	
<?php get_sidebar(); ?>
	
<?php get_footer(); ?>	