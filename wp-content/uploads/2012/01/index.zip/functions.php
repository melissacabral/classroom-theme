<?php
//add custom background. change the bg in appearance > background
add_custom_background();

//automatic RSS feed links on the head of every page
add_theme_support('automatic-feed-links');

//add editor-style.css support
add_editor_style();

//support "featured images" on posts and pages
add_theme_support('post-thumbnails');

//add theme-specific image sizes  (name, width, height, crop)
add_image_size('awesome-tiny', 95, 70, true );
add_image_size('awesome-thumb', 152, 152, true );
add_image_size('awesome-frontpage', 960, 330, true );

//change the excerpt length with a filter hook
function new_ex_length(){
	return 20;
}
add_filter('excerpt_length', 'new_ex_length');

//change [...] to a clickable link with better text 
function new_excerpt_more(){
	return '<a href="'.get_permalink($post->ID).'" class="readmore">Read More</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');




//no closing PHP tag here!