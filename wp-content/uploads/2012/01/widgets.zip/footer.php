</div><!-- end wrapper -->

<div id="footer" class="clearfix">
	<div class="widget-container">
	 <?php 
	//show the sidebar widgets
	//if this WP does not support widgets, or the sidebar does not contain widgets, show alternate content. 
	if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer')): ?>
	
	&copy; 2012 AwesomeCo
	
	<?php endif; ?>
	
	
		
	</div>
</div><!-- end footer -->

<?php 
//must be before </body> for javascript and other things to work
wp_footer(); ?>
</body>
</html>