<?php
//add custom background. change the bg in appearance > background
add_custom_background();

//automatic RSS feed links on the head of every page
add_theme_support('automatic-feed-links');

//add editor-style.css support
add_editor_style();

//support "featured images" on posts and pages
add_theme_support('post-thumbnails');

//add theme-specific image sizes  (name, width, height, crop)
add_image_size('awesome-tiny', 95, 70, true );
add_image_size('awesome-thumb', 152, 152, true );
add_image_size('awesome-frontpage', 960, 330, true );

//change the excerpt length with a filter hook
function new_ex_length(){
	return 20;
}
add_filter('excerpt_length', 'new_ex_length');

//change [...] to a clickable link with better text 
function new_excerpt_more(){
	return '<a href="'.get_permalink($post->ID).'" class="readmore">Read More</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

// Set up Menu Areas
function awesome_menus(){
	if( function_exists('register_nav_menus') ){
		register_nav_menus( array(
			//list of menu areas
			'main-navigation' => 'Main Navigation',
			'utilities' => 'Utilities'
		) );
	}
}
add_action('init','awesome_menus');

//add 4 widget areas
if(function_exists('register_sidebar')){
	register_sidebar(array(
		'name' => 'Blog Sidebar',
		'description' => 'This area appears next to blog posts, archives and search results',
		'before_widget' => '<div id="%1$s" class="widget %2$s" >',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'	
	));	
	
	register_sidebar(array(
		'name' => 'Front Page Sidebar',
		'description' => 'This area appears below the content on the Front Page',
		'before_widget' => '<div id="%1$s" class="widget %2$s" >',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'	
	));
	
	register_sidebar(array(
		'name' => 'Page Sidebar',
		'description' => 'This area appears next to page content',
		'before_widget' => '<div id="%1$s" class="widget %2$s" >',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'	
	));		
	
	register_sidebar(array(
		'name' => 'Footer',
		'description' => 'This area appears at the bottom of every page',
		'before_widget' => '<div id="%1$s" class="widget %2$s" >',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>'	
	));	
}//end if register_sidebar exists






//Breadcrumbs

function dimox_breadcrumbs() {
  $delimiter = '&raquo;';
  $home = 'Home'; // text for the 'Home' link
  $before = '<span class="current">'; // tag before the current crumb
  $after = '</span>'; // tag after the current crumb
 
  if ( ! is_home() && ! is_front_page() || is_paged() ) { 
    echo '<div id="crumbs">'; 
    global $post;
    $homeLink = home_url();
    echo '<a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' ';
 
    if ( is_category() ) {
      global $wp_query;
      $cat_obj = $wp_query->get_queried_object();
      $thisCat = $cat_obj->term_id;
      $thisCat = get_category($thisCat);
      $parentCat = get_category($thisCat->parent);
      if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $delimiter . ' '));
      echo $before . 'Posts in the "' . single_cat_title('', false) . '" category' . $after;
 
    } elseif ( is_day() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('d') . $after;
 
    } elseif ( is_month() ) {
      echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
      echo $before . get_the_time('F') . $after;
 
    } elseif ( is_year() ) {
      echo $before . get_the_time('Y') . $after;
 
    } elseif ( is_single() && ! is_attachment() ) {
      if ( get_post_type() != 'post' ) {
        $post_type = get_post_type_object(get_post_type());
        $slug = $post_type->rewrite;
        echo '<a href="' . $homeLink . '/' . $slug['slug'] . '/">' . $post_type->labels->singular_name . '</a> ' . $delimiter . ' ';
        echo $before . get_the_title() . $after;
      } else {
        $cat = get_the_category(); $cat = $cat[0];
        echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
        echo $before . get_the_title() . $after;
      }
 
    } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
      $post_type = get_post_type_object(get_post_type());
      echo $before . $post_type->labels->singular_name . $after;
 
    } elseif ( is_attachment() ) {
      $parent = get_post($post->post_parent);
      $cat = get_the_category($parent->ID); $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
      echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
      echo $before . get_the_title() . $after;
 
    } elseif ( is_page() && !$post->post_parent ) {
      echo $before . get_the_title() . $after;
 
    } elseif ( is_page() && $post->post_parent ) {
      $parent_id  = $post->post_parent;
      $breadcrumbs = array();
      while ($parent_id) {
        $page = get_page($parent_id);
        $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
        $parent_id  = $page->post_parent;
      }
      $breadcrumbs = array_reverse($breadcrumbs);
      foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $delimiter . ' ';
      echo $before . get_the_title() . $after;
 
    } elseif ( is_search() ) {
      echo $before . 'Search results for "' . get_search_query() . '"' . $after;
 
    } elseif ( is_tag() ) {
      echo $before . 'Posts tagged "' . single_tag_title('', false) . '"' . $after;
 
    } elseif ( is_author() ) {
       global $author;
      $userdata = get_userdata($author);
      echo $before . 'Articles posted by ' . $userdata->display_name . $after;
 
    } elseif ( is_404() ) {
      echo $before . 'Error 404' . $after;
    }
 
    if ( get_query_var('paged') ) {
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
      echo __('Page','wcm400') . ' ' . get_query_var('paged');
      if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
    }
 
    echo '</div>';
 
  }
} // end dimox_breadcrumbs()

//no closing PHP tag here!






