<div id="sidebar">
	<?php 
	//show the sidebar widgets
	//if this WP does not support widgets, or the sidebar does not contain widgets, show alternate content. 
	if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Blog Sidebar')): ?>
	<div class="widget" id="widget-categories">
		<h3 class="widget-title">Categories:</h3>
		<ul>
			<?php wp_list_categories(array(
				'show_count' => 1,
				'number' => 10,
				'title_li' => '',
				'orderby' => 'count',
				'order' => 'desc'
			)); ?>
		</ul>
	</div><!-- end widget -->
	<div class="widget" id="widget-archives">
		<h3 class="widget-title">Archives:</h3>
		<ul>
			<?php wp_get_archives(array(
				'type' => 'yearly'
			)); ?>
		</ul>
	</div><!-- end widget -->
	
	<div class="widget" id="widget-tags">
		<h3 class="widget-title">Tags:</h3>
		
		<?php wp_tag_cloud(); ?>
		
	</div>
	
	<div class="widget" id="widget-meta">
		<h3 class="widget-title">Meta:</h3>
		<ul>
			<li>
				<?php wp_loginout(); ?>
			</li>
		</ul>
	</div>
	<?php endif; ?>
</div><!-- end sidebar -->





