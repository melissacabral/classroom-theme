<div id="sidebar">
 <?php 
	//show the sidebar widgets
	//if this WP does not support widgets, or the sidebar does not contain widgets, show alternate content. 
	if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Sidebar')): ?>
	<?php //fallback stuff goes here ?>
	<?php endif; ?>
</div>