<?php
/*
	Sidebar used on page.php
*/
 ?>
<div id="sidebar">
	<div class="widget" id="widget-subnav">	
		<?php
		//if page has a parent, get the siblings and title of parent
		if($post->post_parent) {
			$children = wp_list_pages("title_li=&child_of=".$post->post_parent."&echo=0");
			$titlenamer = get_the_title($post->post_parent);
			$permalink = get_permalink($post->post_parent);
			//link to the parent page in the title
			$titlenamer = '<a href="'.$permalink.'">'.$titlenamer.'</a>';
		}
		//but if it has children, get them and the title of this page
		else {
			$children = wp_list_pages("title_li=&child_of=".$post->ID."&echo=0");
			$titlenamer = get_the_title($post->ID);
		}
		if ($children) { ?>
		
		<h2> <?php echo $titlenamer; ?> </h2>
		<ul>
			<?php echo $children; ?>
		</ul>
		
		<?php } ?>
	
	</div><!-- end subnav -->
	
	 <?php 
	//show the sidebar widgets
	//if this WP does not support widgets, or the sidebar does not contain widgets, show alternate content. 
	if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('Page Sidebar')): ?>
	<?php //fallback stuff goes here ?>
	<?php endif; ?>
	
</div><!-- end sidebar -->



