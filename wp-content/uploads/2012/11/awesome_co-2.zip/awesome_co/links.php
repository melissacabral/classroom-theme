<?php 
/*
Template Name: Links
*/
?>
<?php get_header(); ?>

<?php //THE LOOP.
if( have_posts() ): 
    while( have_posts() ):
    the_post(); ?>
    
<?php //featured image display. check first to make sure one exists
    if( has_post_thumbnail() ): ?>
        <div class="banner">
        <?php the_post_thumbnail( 'awesome-short-banner' ); ?>
        </div>
<?php endif;?>    

 <div id="content">	
        
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?>>
        <h2 class="entry-title">  
            <?php the_title(); ?> 
        </h2>                

        <div class="entry-content">
            <?php the_content(); ?>
            
            
			<?php wp_list_bookmarks( array(
                'title_before' => '<h3>',
                'title_after' => '</h3>',
                'category_before' => '',
                'category_after' => '',
				'orderby' => 'rand',
				'show_description' => 1
            ) );  //show all links ?>
            
        </div>
   
    </article><!-- end post -->
    
 </div><!-- end content -->
 
  <?php 
  endwhile;
  else: ?>
  <h2>Sorry, no posts found</h2>
  <?php endif; //END OF LOOP. ?>
    

    
<?php get_sidebar(); ?> 
<?php get_footer(); ?>  