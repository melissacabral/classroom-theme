<?php get_header(); ?>

<?php //THE LOOP.
if( have_posts() ): 
    while( have_posts() ):
    the_post(); ?>
    
<?php //featured image display. check first to make sure one exists
    if( has_post_thumbnail() ): ?>
        <div class="banner">
        <?php the_post_thumbnail( 'awesome-short-banner' ); ?>
        </div>
<?php endif;?>    

 <div id="content">	
 
 <?php 
 //safety!  make sure the function exists before running
 if(function_exists('dimox_breadcrumbs')):
 	dimox_breadcrumbs();
 endif; ?>
        
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?>>
        <h2 class="entry-title">  
            <?php the_title(); ?> 
        </h2>                

        <div class="entry-content">
            <?php the_content(); ?>
            
            <div class="pagination">
				<?php //link to pages within the same post using <!--nextpage--> 
				wp_link_pages();  ?>
            </div>
        </div>
   
    </article><!-- end post -->
    
 </div><!-- end content -->
 
  <?php 
  endwhile;
  else: ?>
  <h2>Sorry, no posts found</h2>
  <?php endif; //END OF LOOP. ?>
    

    
<?php get_sidebar(); ?> 
<?php get_footer(); ?>  