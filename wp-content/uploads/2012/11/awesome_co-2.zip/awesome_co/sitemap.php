<?php
/*
Template Name: Sitemap
*/
?>
<?php get_header(); ?>

<?php //THE LOOP.
if( have_posts() ): 
    while( have_posts() ):
    the_post(); ?>
    
<?php //featured image display. check first to make sure one exists
    if( has_post_thumbnail() ): ?>
        <div class="banner">
        <?php the_post_thumbnail( 'awesome-short-banner' ); ?>
        </div>
<?php endif;?>    

 <div id="content">	
 
  <?php 
 //safety!  make sure the function exists before running
 if(function_exists('dimox_breadcrumbs')):
 	dimox_breadcrumbs();
 endif; ?>
        
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?>>
        <h2 class="entry-title">  
            <?php the_title(); ?> 
        </h2>                

        <div class="entry-content">
            <div class="onethird">
            	<h3>Categories</h3>
                <ul>
				<?php wp_list_categories( array(
					'title_li' => '',
					'depth' => -1,
					'feed' => 'rss', //link to view the feed
					'show_count' => 1					
				) ); ?>
				</ul>
            </div><!-- end onethird -->
            
            <div class="onethird">
            	<h3>Pages</h3>
                <ul>
                <?php wp_list_pages( array(
					'title_li' => ''
				) ); ?>
                </ul>
                
                <h3>Archives</h3>
                <ul>
				<?php wp_get_archives( array(
					'show_post_count' => 1
				) ); ?>
                </ul>
            </div><!-- end onethird -->
            
            <div class="onethird">
            	<h3>RSS Feeds</h3>
                <ul>
                	<li><a href="<?php bloginfo('rss2_url') ?>">RSS feed for all posts</a></li>
                    <li><a href="<?php bloginfo('comments_rss2_url') ?>">RSS feed for comments</a></li>
                </ul>
            
            	<h3>Blog Posts</h3>
                <ul>
				<?php wp_get_archives( array(
					'type' => 'postbypost'
				) ); 
				?>
                </ul>
            </div><!-- end onethird -->
        </div>
   
    </article><!-- end post -->
    
 </div><!-- end content -->
 
  <?php 
  endwhile;
  else: ?>
  <h2>Sorry, no posts found</h2>
  <?php endif; //END OF LOOP. ?>
    
<?php get_footer(); ?>  