<?php get_header(); ?>
    
    <div id="content">
    
     <?php 
 //safety!  make sure the function exists before running
 if(function_exists('dimox_breadcrumbs')):
 	dimox_breadcrumbs();
 endif; ?>
 
	<?php 
	//THE LOOP.
	if( have_posts() ): 
		while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
            <h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> 
				<?php the_title(); ?> 
			</a></h2>
            <div class="postmeta"> 
                <span class="author"> Posted by: <?php the_author(); ?> </span> 
                <span class="date"> <?php the_date(); ?> </span> 
                <span class="num-comments"> 
			<?php comments_number('No comments yet', 'One comment', '% comments'); ?></span> 
                <span class="categories"> 
					<?php the_category(); ?>                
                </span> 
                <span class="tags">
					<?php the_tags(); ?>
				</span> 
            </div><!-- end postmeta -->            
            
            <?php 
			//featured image display. check first to make sure one exists
			if( has_post_thumbnail() ): ?>
				<div class="thumb">
				<?php the_post_thumbnail( 'thumbnail' ); ?>
				</div>
            <?php endif;?>
            
            <div class="entry-content">
                <?php 
				//show short versions of the content everywhere except "single" views
				if( is_singular() ):
					the_content();
				else:
					the_excerpt();
				endif; ?>
            </div>
       
        
		<?php 
		//only show comments on posts, not pages
		if( is_single() ):
			comments_template();
		endif; ?>
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>   
        
        <div id="nav-below" class="pagination"> 
        	<?php 
			if( function_exists('wp_pagenavi') ):
				wp_pagenavi();
			else: ?>
             
				<?php next_posts_link( '&larr; Older Posts' ); ?>
                <?php previous_posts_link( 'Newer Posts &rarr;' ); ?>
                
			<?php 
            endif; //function exists ?>
        </div><!-- end #nav-below --> 
        
    </div><!-- end content -->
    
<?php get_sidebar(); ?> 
<?php get_footer(); ?>  