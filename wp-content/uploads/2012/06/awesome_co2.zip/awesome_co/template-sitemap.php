<?php 
/*
Template Name: Auto Sitemap
*/
?>
<?php get_header(); ?>
    
    <div id="content">
	
	<?php 
	if( function_exists('dimox_breadcrumbs') ):
		dimox_breadcrumbs();
	endif; 
	?>
	<?php 
	//THE LOOP.
	if( have_posts() ): 
		while( have_posts() ):
		the_post(); ?>
	
        <article id="post-1" <?php post_class( 'clearfix' ); ?>>
            <h2 class="entry-title"> <a href="<?php the_permalink(); ?>"> 
				<?php the_title(); ?> 
			</a></h2>
            
          	<div class="onethird">
            	<h3>Catgories</h3>
                <ul>
                	<?php wp_list_categories(array(
						'title_li' => '',
						'hierarchical' => 0,
						'feed' => 'rss'
					)); ?>
                </ul>
            </div>
            
            <div class="onethird">
            	<h3>Pages</h3>
                <ul>
                	<?php wp_list_pages(array(
						'title_li' => '',
						'depth' => -1
						
					)); ?>
                </ul>
                
                <h3>Archives</h3>
                <ul>
                	<?php wp_get_archives(array(
						'show_post_count' => 1
					)); ?>
                </ul>
            
            </div>
            
            <div class="onethird">
            	<h3>Feeds</h3>
                <ul>
                	<li><a href="<?php bloginfo('rss2_url'); ?>">
                    	Blog Posts RSS Feed</a></li>
                    <li><a href="<?php bloginfo('comments_rss2_url'); ?>">
                    	Comments RSS Feed</a></li>
                </ul>
                
                <h3>Tags</h3>
                <ul>
                	<?php wp_tag_cloud(array(
						'format' => 'list',
						'unit' => 'em',
						'smallest' => 1,
						'largest' => 1
					)); ?>
                </ul>
            
            </div>
            
              
            
		 </article><!-- end post -->
      <?php 
	  endwhile;
	  else: ?>
	  <h2>Sorry, no posts found</h2>
	  <?php endif; //END OF LOOP. ?>
	          
        
    </div><!-- end content -->
    

<?php get_footer(); ?>  