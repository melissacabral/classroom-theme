jQuery.noConflict();
jQuery(document).ready(function($){
	$('.slides').responsiveSlides({
		nav		: 	true,
		speed	: 	500,
		maxwidth: 	1120
	});	
});
